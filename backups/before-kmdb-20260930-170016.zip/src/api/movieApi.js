// false로 바꾸면 기존 KOBIS 검색만 사용합니다.
// 원본 파일: movieApi.kobis-backup.txt
const USE_KMDB = true;
const KMDB_API_KEY = "6FA20569299763QC295Q";
const KOBIS_API_KEY = "1d3bf4fad446a12663e837e90d49ebcf";
const KMDB_URL = "https://api.koreafilm.or.kr/openapi-data2/wisenut/search_api/search_json2.jsp";
const KOBIS_URL = "https://www.kobis.or.kr/kobisopenapi/webservice/rest/movie/searchMovieList.json";

const asArray = (value) => value == null ? [] : Array.isArray(value) ? value : [value];
const cleanText = (value) => String(value ?? "").replace(/!HS|!HE/g, "").replace(/\s+/g, " ").trim();

// KMDb 응답을 기존 화면의 필드명으로 변환합니다.
function convertMovie(movie) {
  const id = movie.DOCID || movie.docid ||
    (movie.movieId && movie.movieSeq ? `${movie.movieId}${movie.movieSeq}` : "");
  if (!id) throw new Error("KMDb 영화 식별값이 없습니다.");
  const directors = asArray(movie.directors?.director ?? movie.director);
  const actors = asArray(movie.actors?.actor ?? movie.actor);
  return {
    movieCd: `KMDB:${id}`,
    movieNm: cleanText(movie.title),
    movieNmEn: cleanText(movie.titleEng),
    prdtYear: cleanText(movie.prodYear),
    directors: directors.map((person) => ({ peopleNm: cleanText(person.directorNm) })),
    openDt: cleanText(movie.repRlsDate || movie.releaseDate).replace(/-/g, ""),
    genreAlt: cleanText(movie.genre),
    repGenreNm: cleanText(movie.genre).split(",")[0],
    nationAlt: cleanText(movie.nation),
    posterUrl: String(movie.posters || movie.posterUrl || "").split("|")
      .map((url) => url.trim()).find((url) => /^https?:\/\//.test(url)) || "",
    actors: actors.map((person) => cleanText(person.actorNm)).filter(Boolean),
    source: "KMDB",
  };
}

async function searchKmdb(movieName) {
  const params = new URLSearchParams({
    collection: "kmdb_new2", detail: "Y", title: movieName,
    listCount: "10", ServiceKey: KMDB_API_KEY,
  });
  const response = await fetch(`${KMDB_URL}?${params}`, { signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error("KMDb 검색 요청에 실패했습니다.");
  let data;
  try {
    data = JSON.parse(await response.text());
  } catch {
    throw new Error("KMDb 응답을 읽을 수 없습니다. 인증 승인 상태를 확인해주세요.");
  }
  if (data.Error || data.error) throw new Error("KMDb에서 오류를 반환했습니다.");
  const collection = data.Data?.[0];
  if (!collection) {
    if (Number(data.TotalCount) === 0) return [];
    throw new Error("KMDb 응답 구조를 확인해주세요.");
  }
  if (!collection.Result) {
    if (Number(collection.TotalCount) === 0) return [];
    throw new Error("KMDb 영화 목록이 없습니다.");
  }
  if (!Array.isArray(collection.Result)) throw new Error("KMDb 영화 목록 형식이 다릅니다.");
  return collection.Result.map(convertMovie);
}

async function searchKobis(movieName) {
  const params = new URLSearchParams({ key: KOBIS_API_KEY, movieNm: movieName });
  const response = await fetch(`${KOBIS_URL}?${params}`);
  if (!response.ok) throw new Error("영화 검색에 실패했습니다.");
  const data = await response.json();
  if (!Array.isArray(data.movieListResult?.movieList)) throw new Error("KOBIS 검색 결과를 확인할 수 없습니다.");
  return data.movieListResult.movieList;
}

export const searchMovies = async (movieName) => {
  if (USE_KMDB) {
    try {
      return await searchKmdb(movieName);
    } catch (error) {
      console.warn("KMDb 연결 실패로 KOBIS 검색을 사용합니다.", error.message);
    }
  }
  return searchKobis(movieName);
};
