"use client";

import { useState , useRef, useEffect } from "react";
import { searchMovies } from "../api/movieApi";
import ReviewForm from "./ReviewForm";
import MoviePoster from "./MoviePoster";


export default function MovieSearch() {
 const [keyword, setKeyword] = useState("");
 const [movies, setMovies] = useState([]);
 const [selectedMovie, setSelectedMovie] = useState(null);
 const reviewFormRef = useRef(null);
 const [isSearching, setIsSearching] = useState(false);
 const [searchError, setSearchError] = useState("");


 const handleSearch = async () => {
   if (!keyword.trim() || isSearching) return;

   const searchKeyword = keyword.trim();
   setIsSearching(true);
   setSearchError("");
   setSelectedMovie(null);

   try {
     const result = await searchMovies(searchKeyword);

     if (result.length ===0) {
        alert("검색 결과가 없습니다.");
        setKeyword("");
        setMovies([]);
        setSelectedMovie(null);
        return;
     } else {
        setMovies(result);
        setKeyword("");
    }
   } catch (error) {
     setSearchError(error.message);
   } finally {
     setIsSearching(false);
   }
 };


 const handleSelect = (movie) => {
   setSelectedMovie(movie);
   // console.log(movie);
 };

useEffect(() => {
    if (selectedMovie) {
        reviewFormRef.current?.scrollIntoView({
            behavior : "smooth",
            // block : "start",
        });
    }
},[selectedMovie]);


 const handleSaveSuccess = () => {
   setKeyword("");
   setMovies([]);
   setSelectedMovie(null);
 };

 const handleReviewCancel = () => {
    setSelectedMovie(null);
    window.scrollTo({top:0, behavior: "smooth"});
 };


 return (
   <div>
      <form className="movie-search" onSubmit={(e) => { e.preventDefault(); handleSearch(); }}>
        <label htmlFor="movie-keyword">어떤 영화를 보셨나요?</label>
        <div className="search-controls">
        <input
        id="movie-keyword"
        disabled={isSearching}
        type="text"
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        placeholder="영화 제목을 입력하세요"
        />

        <button type="submit" disabled={isSearching}>
        {isSearching ? "검색 중..." : "검색"}
        </button>
        </div>
     </form>
     <p className="search-source">KMDb 영화 정보 · 검색 결과 최대 30편</p>
     {searchError && <p className="records-state" role="alert">{searchError}</p>}

     <div className = "movie-list">
       {movies.map((movie) => (
         <div className = "movie-card" key={movie.docId}>
           <MoviePoster src={movie.posterUrl} title={movie.title} />
           <h3>{movie.title}</h3>
           <p>영문명: {movie.titleEng}</p>
           <p>제작연도: {movie.prodYear}</p>
           <p>
             감독: {movie.directorNm || "정보 없음"}
           </p>
           <p>장르 : {movie.genre}</p>
           <p>배우: {movie.actorNames.slice(0, 5).join(", ") || "정보 없음"}</p>

           <button disabled={isSearching} onClick={() => handleSelect(movie)}>
             기록하기
           </button>
         </div>
       ))}
     </div>


     {selectedMovie && (
        <div className="review-anchor" ref = {reviewFormRef}>
            <ReviewForm
                key={selectedMovie.docId}
                movie={selectedMovie}
                onSaveSuccess={handleSaveSuccess}
                onCancel = {handleReviewCancel}
            />
        </div>
     )}
   </div>
 );
}
