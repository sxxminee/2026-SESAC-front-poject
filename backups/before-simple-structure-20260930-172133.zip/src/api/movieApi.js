export const searchMovies = async (title) => {
  const response = await fetch(`/api/movies?title=${encodeURIComponent(title)}`);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || '영화 검색에 실패했습니다.');
  return data.movies;
};
