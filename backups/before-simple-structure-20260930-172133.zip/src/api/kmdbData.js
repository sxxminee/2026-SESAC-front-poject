// KMDb의 중첩 응답을 화면과 저장에 사용할 한 가지 구조로 정리합니다.
const list = (value) => value == null ? [] : Array.isArray(value) ? value : [value];
const text = (value) => String(value ?? "").replace(/!HS|!HE/g, "").replace(/\s+/g, " ").trim();

export function normalizeMovie(movie) {
  const movieId = text(movie.movieId);
  const movieSeq = text(movie.movieSeq);
  const docId = text(movie.DOCID || movie.docid || (movieId && movieSeq ? `${movieId}${movieSeq}` : ""));
  if (!docId) throw new Error("영화 식별값이 없는 KMDb 응답입니다.");
  const directors = list(movie.directors?.director ?? movie.director);
  const actors = list(movie.actors?.actor ?? movie.actor);
  const posterUrl = text(movie.posters || movie.posterUrl).split("|")
    .map((url) => url.trim()).find((url) => /^https?:\/\//i.test(url)) || "";
  return {
    source: "KMDB", docId, movieId, movieSeq,
    title: text(movie.title), titleEng: text(movie.titleEng), prodYear: text(movie.prodYear),
    directorNm: directors.map((person) => text(person.directorNm)).filter(Boolean).join(", "),
    actorNames: actors.map((person) => text(person.actorNm)).filter(Boolean),
    repRlsDate: text(movie.repRlsDate || movie.releaseDate),
    genre: text(movie.genre), nation: text(movie.nation), posterUrl,
  };
}

export function parseKmdbResponse(body) {
  let data;
  try { data = JSON.parse(body); } catch {
    throw new Error("KMDb 응답을 읽을 수 없습니다. 인증키 승인 상태를 확인해주세요.");
  }
  if (!data || data.Error || data.error || data.errorCode) {
    throw new Error("KMDb 인증 또는 요청 오류입니다. 인증키 승인 상태를 확인해주세요.");
  }
  const collection = data.Data?.[0];
  if (!collection) {
    if (Number(data.TotalCount) === 0) return [];
    throw new Error("KMDb 응답 형식이 예상과 다릅니다.");
  }
  if (!collection.Result && Number(collection.TotalCount) === 0) return [];
  if (!Array.isArray(collection.Result)) throw new Error("KMDb 영화 목록 형식이 올바르지 않습니다.");
  return collection.Result.map(normalizeMovie);
}

// 저장된 기록의 선택 정보가 없으면 화면에서 사용할 기본값을 채웁니다.
export function normalizeReview(record) {
  return {
    ...record,
    actorNames: record.actorNames ?? [],
    posterUrl: record.posterUrl ?? "",
  };
}
